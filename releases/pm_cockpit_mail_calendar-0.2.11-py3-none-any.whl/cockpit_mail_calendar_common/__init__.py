"""Helpers both plugins use: plain text from HTML, clipping, and errors from the services' answers. Plugin code only."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from html.parser import HTMLParser
from pathlib import Path
from typing import Any

from engine.plugin_api import AnswerTooLarge, ConnectorError, Poll, Unreadable

_SKIPPED = {"script", "style", "head"}
_BLOCKS = {"p", "div", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "blockquote"}
_SPACES = re.compile(r"[ \t\r\n\xa0]+")
_CODE = re.compile(r"[A-Za-z0-9_. -]{1,80}")
_REASON = re.compile(r"[A-Za-z0-9_.-]{1,40}")
#: The `reason` of a throttle the host's own gate raised, which an add-on never changes.
GATE = "gate"
_HTML = re.compile(r"</?(a|b|i|u|p|br|div|span|ul|ol|li|strong|em|h[1-6]|table|tr|td|font|blockquote|pre|code)\b", re.I)
_SCHEME = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*://")


def looks_like_html(text: str) -> bool:
    """Whether text has HTML tags in it (plain text from some senders and programs carries HTML)."""
    return bool(_HTML.search(text))


def short_link(href: str, max_chars: int) -> str:
    """A link's address as its host and path: no scheme, query or fragment, no trailing slash, cut at `max_chars`
    with "…". An address that isn't a web address (such as `mailto:`) is only cut."""
    shown = href.strip()
    if _SCHEME.match(shown):
        shown = _SCHEME.sub("", shown).split("?", 1)[0].split("#", 1)[0].rstrip("/")
    return clip(shown, max_chars)


def shipped_app(package_dir: str | Path) -> dict[str, str]:
    """The publisher's app registration shipped inside a plugin package: the strings of `app.json` next to the
    package's `__init__.py`. Empty when the file is missing, empty, unreadable, not a JSON object, or holds anything
    but non-empty strings. Never raises and never reports a value."""
    try:
        data = json.loads((Path(package_dir) / "app.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    if not isinstance(data, dict) or not data:
        return {}
    if not all(isinstance(key, str) and isinstance(value, str) and value.strip() for key, value in data.items()):
        return {}
    return {key: value.strip() for key, value in data.items()}


def clip(text: str, max_chars: int) -> str:
    """Cut plain text to at most `max_chars`, ending with "…" when it was cut."""
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 1].rstrip() + "…" if max_chars > 0 else ""


class _Text(HTMLParser):
    def __init__(self, max_link_chars: int | None = None) -> None:
        super().__init__(convert_charrefs=True)
        self.max_link_chars = max_link_chars
        self.parts: list[str] = []
        self.skipping = 0
        self.at_line_start = True
        self.link: tuple[str, int] | None = None

    def _break(self, *, hard: bool = False) -> None:
        if hard or not self.at_line_start:
            self.parts.append("\n")
            self.at_line_start = True

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in _SKIPPED:
            self.skipping += 1
        elif self.skipping:
            return
        elif tag == "br":
            self._break(hard=True)
        elif tag in _BLOCKS:
            self._break()
            if tag == "li":
                self.parts.append("- ")
                self.at_line_start = False
        elif tag in ("td", "th"):
            if not self.at_line_start:
                self.parts.append(" ")  # table cells of one row stay apart
        elif tag == "a":
            self.link = (dict(attrs).get("href") or "", len(self.parts))

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag: str) -> None:
        if tag in _SKIPPED:
            self.skipping = max(0, self.skipping - 1)
        elif self.skipping:
            return
        elif tag in _BLOCKS:
            self._break()
        elif tag == "a" and self.link:
            href, start = self.link
            self.link = None
            label = "".join(self.parts[start:]).strip()
            plain = href.removeprefix("mailto:")
            if label and href and not href.startswith(("#", "javascript:")) and label not in (href, plain):
                if self.max_link_chars is None:
                    self.parts.append(f" ({href})")
                else:
                    whole = short_link(href, 10**9)
                    shown = short_link(href, self.max_link_chars)
                    if shown and label.rstrip("/") not in (whole, shown):
                        self.parts.append(f" ({shown})")

    def handle_data(self, data: str) -> None:
        if self.skipping:
            return
        text = _SPACES.sub(" ", data)
        if text.strip() or not self.at_line_start:
            self.parts.append(text)
            self.at_line_start = False


def html_to_text(html: str, max_chars: int, max_link_chars: int | None = None) -> str:
    """Plain text from HTML: no scripts or styles, one line per block, links as `text (address)`, cut at `max_chars`.
    With `max_link_chars`, an address is shortened to its host and path, cut at that length (0 leaves addresses out),
    and left out when the link's text already is it."""
    parser = _Text(max_link_chars)
    parser.feed(html)
    parser.close()
    lines: list[str] = []
    for line in "".join(parser.parts).split("\n"):
        line = _SPACES.sub(" ", line).strip()
        if line or (lines and lines[-1]):
            lines.append(line)
    return clip("\n".join(lines).strip(), max_chars)


def _error_code(body: Any) -> str:
    """The service's own error code from an error body: Graph's `code`, or Google's `status` or first `reason`."""
    error = body.get("error") if isinstance(body, dict) else None
    candidates: list[Any] = []
    if isinstance(error, str):
        candidates.append(error)
    elif isinstance(error, dict):
        # Google's numeric `code` (such as 410) is no use; its `status` or first `reason` is the name.
        details = error.get("errors")
        reason = (
            details[0].get("reason") if isinstance(details, list) and details and isinstance(details[0], dict) else None
        )
        candidates += [error.get("code"), error.get("status"), reason]
    code = next((c for c in candidates if isinstance(c, str) and _CODE.fullmatch(c)), None)
    return code or "none"


def clean_reason(code: Any) -> str | None:
    """`code` when it may be a `ConnectorError` reason (letters, digits, `_`, `-` and `.`, at most 40), else None."""
    return code if isinstance(code, str) and _REASON.fullmatch(code) else None


def _first_string(*candidates: Any) -> str | None:
    return next((c for c in candidates if isinstance(c, str) and c), None)


def reason_from_body(body: Any, service: str) -> str | None:
    """The service's own short error code from an error body, ready for `ConnectorError(reason=)`, or None when the
    body has none or it doesn't fit. Google (`service` "Google"): `error.errors[0].reason`, else the `reason` of an
    `ErrorInfo` entry in `error.details`. Anything else (Graph): `error.code`, else `error.innerError.code`."""
    error = body.get("error") if isinstance(body, dict) else None
    if not isinstance(error, dict):
        return None
    if service == "Google":
        errors, details = error.get("errors"), error.get("details")
        first = errors[0] if isinstance(errors, list) and errors else None
        found = first.get("reason") if isinstance(first, dict) else None
        if not isinstance(found, str) or not found:
            found = next(
                (
                    d.get("reason")
                    for d in (details if isinstance(details, list) else [])
                    if isinstance(d, dict) and d.get("@type") == "type.googleapis.com/google.rpc.ErrorInfo"
                ),
                None,
            )
        return clean_reason(found)
    inner = error.get("innerError")
    return clean_reason(_first_string(error.get("code"), inner.get("code") if isinstance(inner, dict) else None))


def with_reason(err: ConnectorError, service: str) -> ConnectorError:
    """The error the web client raised, carrying the service's reason code from its body. An error that already has a
    reason (the host's own gate throttle, `reason == "gate"`) is returned as it is, never reshaped."""
    if err.reason:
        return err
    reason = reason_from_body(err.json(), service)
    if reason is None:
        return err
    return ConnectorError(
        err.kind,
        err.detail,
        retry_after=err.retry_after,
        status=err.status,
        headers=err.headers,
        body=err.body,
        advice_key=err.advice_key,
        reason=reason,
    )


def service_error(status: int, body: Any, service: str) -> ConnectorError:
    """The error for a status the web client hands back instead of raising. Decided from the status and the
    service's error code only, and the detail never quotes the body's message."""
    code = _error_code(body)
    reason = reason_from_body(body, service)
    if status == 400:
        return ConnectorError(
            "outage", f"{service}: the service refused the request (status 400, code {code})", reason=reason
        )
    kind = "not_found" if status == 410 else "outage"
    return ConnectorError(kind, f"{service}: the service answered {status} (code {code})", reason=reason)


def scope_granted(allowed: set[str], scope: str) -> bool:
    """Whether `scope` is among the scopes the person `allowed`: written the same, or with the same part after the
    last `/` (Graph answers `Mail.Read` or `https://graph.microsoft.com/Mail.Read`; Google answers full addresses)."""
    tail = scope.rsplit("/", 1)[-1]
    return any(found == scope or found.rsplit("/", 1)[-1] == tail for found in allowed)


def require_scope(context: Any, sign_in: str, scope: str, words: str) -> None:
    """Raise `no_access` with `words` when the person didn't allow `scope` when they signed in. Call it after the
    sign-in's token is asked for (a withdrawn sign-in is `auth`, not this) and before the first request. A context that
    can't say what was allowed, such as a test's, allows everything."""
    granted = getattr(context, "granted", None)
    if granted is not None and not scope_granted(granted(sign_in), scope):
        raise ConnectorError("no_access", words)


SKIPPABLE = ("outage", "no_access", "not_found")


def unreadable_entry(key: str, err: ConnectorError) -> Unreadable:
    """A message that could not be read, named by its key, with the kind and status only (never the service's text).
    An answer too large to take in is marked `kind="too_large"`, decided by the error's class, never its text."""
    if isinstance(err, AnswerTooLarge):
        return Unreadable(key, "The message is too large to read.", kind="too_large")
    status = getattr(err, "status", None)
    detail = f"{err.kind}, status {status}" if status else err.kind
    return Unreadable(key, f"The message could not be read ({detail}).")


class MessageFetches:
    """Keeps count of one read's single-message fetches, so one bad message is skipped and named while a service
    that is down (every fetch failing) still fails the read. Only `outage`, `no_access` and `not_found` are ever
    skipped; any other kind (auth, offline, throttled) is raised at once. An `AnswerTooLarge` is always skipped and
    named (it is the message, not the service): it is neutral toward "two failures in a row", neither counting as a
    failure nor breaking a run of them. A `not_found` is a message gone since it
    was listed: skipped quietly, never named."""

    def __init__(self) -> None:
        self.worked = 0
        self.errors: list[ConnectorError] = []  # outage and no_access, in order
        self.unreadable: list[Unreadable] = []
        self.last: tuple[str, Unreadable] | None = None  # the failure just before, when nothing worked since
        self.stopped = False  # two failures in a row: the service is failing, not the messages
        self.first_failed = ""  # the key of the first of those two

    def worked_once(self) -> None:
        self.worked += 1
        self.last = None

    def failed(self, key: str, err: ConnectorError) -> None:
        """Note a failed fetch of the message `key`; raises `err` when its kind is never skipped."""
        if isinstance(err, AnswerTooLarge):  # before anything that goes by kind
            self.unreadable.append(unreadable_entry(key, err))
            return
        if err.kind not in SKIPPABLE:
            raise err
        if err.kind == "not_found":
            self.worked_once()  # the service answered: nothing is wrong with it
            return
        self.errors.append(err)
        if self.last is not None:
            # A second failure in a row: the first is not named after all, and the read should stop.
            self.unreadable.remove(self.last[1])
            self.stopped, self.first_failed = True, self.last[0]
            return
        entry = unreadable_entry(key, err)
        self.unreadable.append(entry)
        self.last = (key, entry)

    def stop_after(self, key: str, err: ConnectorError) -> ConnectorError | None:
        """Note a failed fetch like `failed`, for a look further back that can hand in what it read. Returns the error
        that stops the read (a throttled or offline answer, or the last of two failures in a row that mean the service
        is failing); None when the read goes on. Any other kind is raised."""
        try:
            self.failed(key, err)
        except ConnectorError as raised:
            if raised.kind not in STOPS:
                raise
            return raised
        return self.errors[-1] if self.stopped else None

    def check(self) -> None:
        """Raise the first error when every fetch of the read failed."""
        if self.errors and not self.worked:
            raise self.errors[0]


STOPS = ("throttled", "outage", "offline")  # the errors that end a look further back partway, keeping what it read


@dataclass(frozen=True)
class Reach:
    """How far one list a look further back reads has been read: whether it is finished, and the date of the oldest
    message read from it (None when none has been)."""

    finished: bool
    oldest: Any = None


def keep_without_gap[T](reaches: list[Reach], items: list[tuple[Any, T]]) -> list[T]:
    """The items (each with its date) a stopped look further back may hand in. The next try asks for what is older
    than the oldest item handed in, so everything newer than it must have been read. Each unfinished list has read
    back to its own oldest date; the cutoff is the newest of those, and only the items dated on or after it are kept.
    A list not reached at all leaves no cutoff, so nothing is kept. When every list is finished, all are kept."""
    cutoffs = []
    for reach in reaches:
        if reach.finished:
            continue
        if reach.oldest is None:
            return []
        cutoffs.append(reach.oldest)
    if not cutoffs:
        return [item for _, item in items]
    cutoff = max(cutoffs)
    return [item for date, item in items if date >= cutoff]


def stopped_poll(items: list[Any], unreadable: list[Unreadable], stop: ConnectorError | None) -> Poll:
    """The answer of a look further back: what it read, with `stopped` set when it ended early. A stop with nothing
    read is raised, as an error always was."""
    if stop is None:
        return Poll(items=items, unreadable=unreadable)
    if not items:
        raise stop
    return Poll(items=items, unreadable=unreadable, stopped=stop)
