"""The Gmail and Google Calendar channels: how an act the person approved is carried out.

A channel is called only by the host's publisher, for an act the person said yes to. It looks up what the act needs,
makes the request `acting.py` describes, and answers `ChannelSent`, `ChannelFailed` (only when it is sure nothing went
out) or `ChannelUnknown` (an outage, throttling or a timeout on the request that does the act: it may have gone
through). `status` never says "not sent". Nothing here deletes or bins mail.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
from collections.abc import Callable
from typing import Any
from urllib.parse import quote, urlsplit

from engine.plugin_api import (
    ChannelContext,
    ChannelFailed,
    ChannelFolder,
    ChannelSent,
    ChannelUndone,
    ChannelUnknown,
    ConnectorError,
    OutgoingAct,
)

from cockpit_mail_calendar_common import scope_granted

from . import acting
from .api import CALENDAR, GMAIL, RATE_LIMITS, _api_turned_off
from .sign_in import ACTING_SCOPES

MAIL_CHANNEL = "google/mail-channel"
CALENDAR_CHANNEL = "google/calendar-channel"
MAIL_SCOPE, CALENDAR_SCOPE = ACTING_SCOPES
NO_SUCH_DATE = "That date of the meeting isn't in the calendar any more."
ACTING_NOT_ALLOWED = (
    "Acting isn't allowed for this account yet. Turn on acting for it again and allow it on Google's page."
)
#: The most messages one `batchModify` takes.
MAX_MESSAGES = 1000
#: Google's reasons (or status names) that say the sign-in lacks the scope this request needs.
_SCOPE_CODES = {"insufficientPermissions", "ACCESS_TOKEN_SCOPE_INSUFFICIENT"}

Answer = ChannelSent | ChannelFailed | ChannelUnknown


def attempt_hash(attempt_key: str) -> str:
    """The first 32 hex characters of the key's SHA-256: what an event carries so a lost answer can be settled."""
    return hashlib.sha256(attempt_key.encode("utf-8")).hexdigest()[:32]


class _Stop(Exception):
    """Ends the work with this answer."""

    def __init__(self, answer: Answer):
        super().__init__(str(answer))
        self.answer = answer


def _codes(err: ConnectorError | None, body: Any = None) -> list[str]:
    """Google's own error codes from an error body: every `reason` in `error.errors` and `error.details`, then
    `error.status`. Codes only, never the message."""
    if body is None and err is not None:
        body = err.json()
    error = body.get("error") if isinstance(body, dict) else None
    if not isinstance(error, dict):
        return []
    found: list[str] = []
    for key in ("errors", "details"):
        entries = error.get(key)
        for entry in entries if isinstance(entries, list) else []:
            reason = entry.get("reason") if isinstance(entry, dict) else None
            if isinstance(reason, str) and reason:
                found.append(reason)
    if isinstance(error.get("status"), str):
        found.append(error["status"])
    return found


def _code_words(codes: list[str]) -> str:
    code = next((c for c in codes if c.replace("_", "").replace("-", "").isalnum() and len(c) <= 80), None)
    return code or "none"


def _json(content: bytes) -> Any:
    import json

    try:
        return json.loads(content)
    except ValueError:
        return None


class _Call:
    """The requests of one call, with the account's token. `lookup` is a request made before the act; `act` is the
    request that does it, whose failure to answer may mean it went through."""

    def __init__(self, context: ChannelContext, scope: str | None, *, undoing: bool = False):
        self.context = context
        self.undoing = undoing
        self.account = context.account or ""
        self.who = self.account.partition(":")[2] or self.account or "your Google account"
        self.acted = False
        self.sent = False  # whether a request of this call has gone out (the host's gate refuses without sending)
        self.did: dict[str, Any] = {}  # what this call has changed so far, handed to the host with an unclear answer
        self.reason: str | None = None  # how far an unclear answer got, as a short code
        self.headers = {"Authorization": f"Bearer {self._token()}"}
        if scope is not None and not scope_granted(set(context.granted or ()), scope):
            raise _Stop(ChannelFailed("refused", ACTING_NOT_ALLOWED))

    def _token(self) -> str:
        try:
            token = self.context.access_token()
        except ConnectorError as err:
            if err.kind == "offline":
                raise _Stop(ChannelFailed("offline", "Couldn't reach Google. Check the connection.")) from None
            if err.kind in ("auth", "no_access"):
                raise _Stop(ChannelFailed("auth", f"Sign in to {self.who} again.")) from None
            raise _Stop(ChannelFailed("outage", "Google's sign-in couldn't be renewed just now.")) from None
        if not token:
            raise _Stop(ChannelFailed("auth", f"Sign in to {self.who} again."))
        return token

    def address(self) -> str:
        """The signed-in address, which is the sender."""
        address = self.who.strip()
        if "@" not in address or any(c.isspace() or c in "<>" for c in address):
            raise ValueError("The account has no address to send from")
        return address

    # ---- requests ------------------------------------------------------------------------------------------------

    def lookup(self, url: str, params: dict | None = None) -> Any:
        """A GET made before the act. Returns the decoded JSON object; any failure is `ChannelFailed`."""
        _, body = self._send("GET", url, params, None, acts=False)
        if not isinstance(body, dict):
            raise _Stop(ChannelFailed("outage", "Google's answer couldn't be read."))
        return body

    def act(
        self, method: str, url: str, params: dict | None = None, body: dict | None = None, *, gone_ok: bool = False
    ) -> tuple[int, Any]:
        """The request that does the act. With `gone_ok`, an event that is already gone (404 or 410) is done."""
        _never_deletes_mail(method, url, body)  # before anything is marked as made
        self.acted = not self.undoing
        return self._send(method, url, params, body, acts=not self.undoing, gone_ok=gone_ok)

    def _send(
        self, method: str, url: str, params: dict | None, body: dict | None, *, acts: bool, gone_ok: bool = False
    ) -> tuple[int, Any]:
        _never_deletes_mail(method, url, body)
        web = self.context.web
        call: Callable[..., Any] = {
            "GET": web.get,
            "POST": web.post,
            "PATCH": web.patch,
            "DELETE": web.delete,
        }[method]
        arguments: dict[str, Any] = {"headers": self.headers}
        if params:
            arguments["params"] = params
        if body is not None:
            arguments["json"] = body
        try:
            response = call(url, **arguments)
        except ConnectorError as err:
            if err.kind == "throttled" and err.reason == "gate":  # the core's gate sent nothing
                if not self.sent:
                    raise _Stop(
                        ChannelFailed(
                            "outage",
                            "Google asked to wait before more requests, so nothing was sent. "
                            "Try again in a few minutes.",
                        )
                    ) from None
            else:
                self.sent = True
            if gone_ok and err.kind == "not_found":
                return 404, None
            raise _Stop(self._from_error(err, acts)) from None
        self.sent = True
        status = response.status
        decoded = _json(response.content) if response.content else None
        if 200 <= status < 300:
            return status, decoded
        if gone_ok and status in (404, 410):
            return status, decoded
        if status == 408 or not 400 <= status < 500:
            # A request timeout, a redirect or anything else unexpected: no clear answer.
            raise _Stop(self._unclear(acts, f"Google answered {status}"))
        raise _Stop(ChannelFailed("refused", self._refusal(status, _codes(None, decoded))))

    def _unclear(self, acts: bool, why: str) -> Answer:
        if acts:
            return ChannelUnknown()
        return ChannelFailed("outage", f"{why}. Try again in a little while.")

    def _refusal(self, status: int | None, codes: list[str]) -> str:
        if _SCOPE_CODES & set(codes):
            return ACTING_NOT_ALLOWED
        return f"Google refused it (status {status if status is not None else 'none'}, code {_code_words(codes)})."

    def _from_error(self, err: ConnectorError, acts: bool) -> Answer:
        codes = _codes(err)
        if err.kind == "auth":
            return ChannelFailed("auth", f"Sign in to {self.who} again.")
        if err.kind == "no_access":
            if RATE_LIMITS & set(codes):
                return self._unclear(acts, "Google asked to wait")
            if _api_turned_off(err):
                return ChannelFailed(
                    "refused", "Google's API for this is turned off in the project of the app you signed in with."
                )
            return ChannelFailed("refused", self._refusal(err.status, codes))
        if err.kind == "not_found":
            return ChannelFailed("refused", "Google says it isn't there (status 404).")
        if err.kind == "offline":
            return ChannelFailed("offline", "Couldn't reach Google. Check the connection and try again.")
        # outage, throttled, or anything else: the service did not answer clearly.
        return self._unclear(acts, "Google didn't answer clearly")


def _never_deletes_mail(method: str, url: str, body: dict | None) -> None:
    """Refuses any Gmail request that could delete or bin mail, whatever asked for it."""
    parts = urlsplit(url)
    if (parts.hostname or "").lower() == "gmail.googleapis.com":
        path = parts.path.lower()
        if method == "DELETE" or "trash" in path or "delete" in path:
            raise ValueError("Mail is never deleted or put in the bin")
    if isinstance(body, dict):
        for key in ("addLabelIds", "removeLabelIds"):
            if any(str(label).upper() == "TRASH" for label in body.get(key) or ()):
                raise ValueError("Mail is never deleted or put in the bin")


def _run(
    context: ChannelContext, scope: str | None, work: Callable[[_Call], Answer], *, undoing: bool = False
) -> Answer:
    """Runs `work` with a call. A refusal before any request is `refused`; the same after the act's request was made
    is `ChannelUnknown`, because the act may have gone through."""
    call: _Call | None = None
    try:
        call = _Call(context, scope, undoing=undoing)
        return _unknown_with_did(call, work(call))
    except _Stop as stop:
        return _unknown_with_did(call, stop.answer)
    except ValueError as err:
        if call is not None and call.acted:
            return _unknown_with_did(call, ChannelUnknown())
        return ChannelFailed("refused", str(err))


def _unknown_with_did(call: _Call | None, answer: Answer) -> Answer:
    """An unclear answer carries how far the call got and what it had changed by then."""
    if call is not None and isinstance(answer, ChannelUnknown) and answer.did is None and answer.reason is None:
        return ChannelUnknown(reason=call.reason, did=dict(call.did) or None)
    return answer


def _first_id(act: OutgoingAct, what: str) -> str:
    found = next((a.service_id for a in act.about if a.service_id), None)
    if not found:
        raise ValueError(f"The act names no {what}")
    return found


def _sent_id(body: Any, did: Callable[[str], dict[str, Any]], fallback: str | None = None) -> Answer:
    found = body.get("id") if isinstance(body, dict) else None
    if isinstance(found, str) and found:
        return ChannelSent(found, did=did(found))
    # It was accepted but the answer didn't say which: status can find it by its key.
    return ChannelSent(fallback, did=did(fallback)) if fallback else ChannelUnknown()


def _strings(value: Any) -> list[str]:
    return [v for v in value if isinstance(v, str) and v] if isinstance(value, list) else []


def _did_text(act: OutgoingAct, key: str) -> str | None:
    found = (act.did or {}).get(key)
    return found if isinstance(found, str) and found else None


# ---- mail -------------------------------------------------------------------------------------------------------


def _headers(message: dict) -> dict[str, str]:
    """A message's headers by lower-case name (the first of each), from a `format=metadata` answer."""
    entries = (message.get("payload") or {}).get("headers")
    found: dict[str, str] = {}
    for entry in entries if isinstance(entries, list) else []:
        if isinstance(entry, dict) and isinstance(entry.get("name"), str) and isinstance(entry.get("value"), str):
            found.setdefault(entry["name"].lower(), entry["value"])
    return found


def _label_ids(call: _Call) -> dict[str, str]:
    body = call.lookup(f"{GMAIL}/labels")
    labels = body.get("labels")
    return {
        entry["name"]: entry["id"]
        for entry in labels if isinstance(labels, list) and isinstance(entry, dict)
        if isinstance(entry.get("name"), str) and isinstance(entry.get("id"), str)
    }  # fmt: skip


#: System labels a person files to, by the name Gmail shows. Every other system label is left out.
_FILING_SYSTEM_LABELS = {"STARRED": "Starred", "IMPORTANT": "Important"}


def folders(account: str, context: ChannelContext) -> list[ChannelFolder] | ChannelFailed:
    """The labels Move to and Label offer: the person's own, plus Starred and Important. Gmail has no folders, so
    each is listed as a folder and as a label with the same id. Read-only: one request."""

    def work(call: _Call) -> Any:
        body = call.lookup(f"{GMAIL}/labels")
        entries = body.get("labels")
        found: dict[str, str] = {}
        for entry in entries if isinstance(entries, list) else []:
            if not isinstance(entry, dict) or not isinstance(entry.get("id"), str) or not entry["id"]:
                continue
            if entry.get("type") == "user" and isinstance(entry.get("name"), str) and entry["name"]:
                found[entry["id"]] = entry["name"]
            elif entry["id"] in _FILING_SYSTEM_LABELS:
                found[entry["id"]] = _FILING_SYSTEM_LABELS[entry["id"]]
        ordered = sorted(found.items(), key=lambda pair: (pair[1].casefold(), pair[1], pair[0]))
        return [ChannelFolder(id=i, name=n, kind=k) for i, n in ordered for k in ("folder", "label")]

    return _run(context, None, work)  # type: ignore[return-value]


def _send_message(call: _Call, act: OutgoingAct, attempt_key: str) -> Answer:
    done = _did_text(act, "message")
    if done:  # a retry of a send that already went out never sends again
        return ChannelSent(done, did=dict(act.did or {}))
    sender = call.address()
    wanted = act.action in ("reply", "reply_all", "forward")
    original: dict | None = None
    thread: str | None = None
    if wanted:
        original_id = quote(_first_id(act, "message to answer"), safe="")
        if act.action == "forward":
            message = call.lookup(f"{GMAIL}/messages/{original_id}", {"format": "raw"})
            raw = message.get("raw")
            try:
                decoded = base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4)) if isinstance(raw, str) else b""
            except (binascii.Error, ValueError):
                decoded = b""
            original = {"raw": decoded}
        else:
            message = call.lookup(
                f"{GMAIL}/messages/{original_id}",
                {"format": "metadata", "metadataHeaders": ["Message-ID", "References"]},
            )
            original = _headers(message)
            thread = message.get("threadId") if isinstance(message.get("threadId"), str) else None
    mime = acting.build_message(
        act, sender=sender, message_id=acting.message_id(attempt_key, call.account), original=original
    )
    call.reason = "send_unclear"
    _, body = call.act("POST", f"{GMAIL}/messages/send", body=acting.send_request(mime, thread))
    sent_thread = body.get("threadId") if isinstance(body, dict) else None
    where = sent_thread if isinstance(sent_thread, str) and sent_thread else thread
    return _sent_id(body, lambda message: {"message": message, **({"thread": where} if where else {})})


def _labels_on(call: _Call, message: str) -> set[str]:
    body = call.lookup(f"{GMAIL}/messages/{quote(message, safe='')}", {"format": "minimal"})
    return set(_strings(body.get("labelIds")))


def _label_did(changed: list[str], added: dict[str, list[str]], removed: dict[str, list[str]]) -> dict[str, Any]:
    """What a mailbox act changed: the messages, the labels added and removed. When the messages did not all change
    the same way, `added_to` and `removed_from` say which messages each label went on or came off."""
    did: dict[str, Any] = {"messages": changed, "added": list(added), "removed": list(removed)}
    everyone = set(changed)
    if any(set(ids) != everyone for ids in (*added.values(), *removed.values())):
        did["added_to"] = {label: list(ids) for label, ids in added.items()}
        did["removed_from"] = {label: list(ids) for label, ids in removed.items()}
    return did


def _label_changes(did: Any) -> tuple[dict[str, list[str]], dict[str, list[str]]]:
    """The labels a did says were added and removed, each with the messages it concerned."""
    did = did if isinstance(did, dict) else {}
    messages = _strings(did.get("messages"))

    def side(each: str, plain: str) -> dict[str, list[str]]:
        mapped = did.get(each)
        if isinstance(mapped, dict):
            return {str(k): _strings(v) for k, v in mapped.items()}
        return {label: list(messages) for label in _strings(did.get(plain))}

    return side("added_to", "added"), side("removed_from", "removed")


def _merge(first: dict[str, list[str]], second: dict[str, list[str]]) -> dict[str, list[str]]:
    merged = {label: list(ids) for label, ids in first.items()}
    for label, ids in second.items():
        merged[label] = list(dict.fromkeys([*merged.get(label, []), *ids]))
    return merged


def _group(adds: dict[str, set[str]], removes: dict[str, set[str]], order: list[str]) -> list[tuple[dict, list[str]]]:
    """Messages that need the same change, as one `batchModify` body each."""
    groups: dict[tuple[tuple[str, ...], tuple[str, ...]], list[str]] = {}
    for message in order:
        key = (
            tuple(sorted(label for label, ids in adds.items() if message in ids)),
            tuple(sorted(label for label, ids in removes.items() if message in ids)),
        )
        if key[0] or key[1]:
            groups.setdefault(key, []).append(message)
    found = []
    for (adding, removing), ids in groups.items():
        body: dict[str, Any] = {"ids": ids}
        if adding:
            body["addLabelIds"] = list(adding)
        if removing:
            body["removeLabelIds"] = list(removing)
        found.append((body, ids))
    return found


def _change_mailbox(call: _Call, act: OutgoingAct) -> Answer:
    if len([a for a in act.about if a.service_id]) > MAX_MESSAGES:
        raise ValueError(f"Gmail changes at most {MAX_MESSAGES} messages at a time")
    labels = _label_ids(call) if act.action in ("move", "label") else {}
    do, _ = acting.mailbox_change(act, label_ids=labels)
    wanted_add, wanted_remove = _strings(do.get("addLabelIds")), _strings(do.get("removeLabelIds"))
    # Only what is still undone: a label already on a message isn't added, and one that's gone isn't removed.
    needs_add: dict[str, set[str]] = {label: set() for label in wanted_add}
    needs_remove: dict[str, set[str]] = {label: set() for label in wanted_remove}
    for message in do["ids"]:
        have = _labels_on(call, message)
        for label in wanted_add:
            if label not in have:
                needs_add[label].add(message)
        for label in wanted_remove:
            if label in have:
                needs_remove[label].add(message)
    added, removed = _label_changes(act.did)  # what an earlier try of this act already did
    changed = _strings((act.did or {}).get("messages"))
    call.did = _label_did(changed, added, removed) if changed else {}
    call.reason = "labels_unclear"
    for body, ids in _group(needs_add, needs_remove, list(do["ids"])):
        try:
            call.act("POST", f"{GMAIL}/messages/batchModify", body=body)
        except _Stop as stop:
            if call.did and isinstance(stop.answer, ChannelFailed):
                raise _Stop(ChannelUnknown()) from None
            raise
        changed = list(dict.fromkeys([*changed, *ids]))
        added = _merge(
            added, {label: [m for m in ids if m in needs_add.get(label, ())] for label in body.get("addLabelIds", [])}
        )
        removed = _merge(
            removed,
            {label: [m for m in ids if m in needs_remove.get(label, ())] for label in body.get("removeLabelIds", [])},
        )
        call.did = _label_did(changed, added, removed)
    return ChannelSent(do["ids"][0], did=_label_did(changed, added, removed))


def send_mail(act: OutgoingAct, attempt_key: str, context: ChannelContext) -> Answer:
    """Carry out an approved message or mailbox act."""

    def work(call: _Call) -> Answer:
        if act.kind == "message":
            return _send_message(call, act, attempt_key)
        if act.kind == "mailbox":
            return _change_mailbox(call, act)
        raise ValueError(f"Gmail can't do a {act.kind} act")

    return _run(context, MAIL_SCOPE, work)


# ---- calendar ---------------------------------------------------------------------------------------------------


def _attendees(event: dict) -> list[dict]:
    found = event.get("attendees")
    return [a for a in found if isinstance(a, dict)] if isinstance(found, list) else []


def _instance(call: _Call, act: OutgoingAct, event_id: str, event: dict) -> tuple[str, dict]:
    """The event to answer: the date's own instance when the act is about one date of a series, else the event."""
    occurrence = next((a.occurrence for a in act.about if a.service_id == event_id and a.occurrence), None)
    if not occurrence or not event.get("recurrence"):
        return event_id, event
    found = call.lookup(CALENDAR + acting._events(act, event_id) + "/instances", {"originalStart": occurrence})
    items = found.get("items")
    for item in items if isinstance(items, list) else []:
        if isinstance(item, dict) and isinstance(item.get("id"), str) and item["id"]:
            return item["id"], item
    raise _Stop(ChannelFailed("refused", NO_SUCH_DATE))


def _calendar_act(call: _Call, act: OutgoingAct, attempt_key: str) -> Answer:
    if act.action == "create":
        done = _did_text(act, "event")
        if done:  # a retry of an event that was made never makes a second one
            return ChannelSent(done, did=dict(act.did or {}))
        method, path, params, body = acting.create_event(act)
        body = {**(body or {}), "extendedProperties": {"private": {"pmcAttempt": attempt_hash(attempt_key)}}}
        _, answer = call.act(method, CALENDAR + path, params, body)
        return _sent_id(answer, lambda event: {"event": event})
    event_id = acting._event_id(act)
    did: dict[str, Any]
    if act.action == "answer":
        # Check the act is fit to make before any request: a stand-in attendee that is "self" passes only if it is.
        acting.answer_event(act, attendees=[{"self": True}])
        target = _did_text(act, "event")
        event = call.lookup(CALENDAR + acting._events(act, target or event_id))
        if target is None:
            target, event = _instance(call, act, event_id, event)
        attendees = _attendees(event)
        before = (act.did or {}).get("answer")
        old = before if isinstance(before, str) else acting.own_answer(act, attendees)
        method, path, params, body = acting.answer_event(act, attendees=attendees, event_id=target)
        did = {"event": target, "answer": old}
    elif act.action == "move":
        method, path, params, body = acting.move_event(act)
        start, end = _did_text(act, "start"), _did_text(act, "end")
        if start is None or end is None:
            event = call.lookup(CALENDAR + acting._events(act, event_id))
            start, end = acting.event_time(event.get("start")), acting.event_time(event.get("end"))
        did = {"event": event_id, "start": start, "end": end}
    elif act.action == "cancel":
        method, path, params, body = acting.cancel_event(act)
        did = {"event": event_id}
    else:
        raise ValueError(f"Google Calendar can't do '{act.action}'")
    call.act(method, CALENDAR + path, params, body, gone_ok=act.action == "cancel")
    return ChannelSent(event_id, did=did)


def send_calendar(act: OutgoingAct, attempt_key: str, context: ChannelContext) -> Answer:
    """Carry out an approved calendar act."""

    def work(call: _Call) -> Answer:
        if act.kind != "calendar":
            raise ValueError(f"Google Calendar can't do a {act.kind} act")
        return _calendar_act(call, act, attempt_key)

    return _run(context, CALENDAR_SCOPE, work)


# ---- undo -------------------------------------------------------------------------------------------------------

CANT_TAKE_BACK = "This can't be taken back here. Look in Gmail or Google Calendar."


def _back_bodies(did: dict) -> list[dict]:
    """The `batchModify` bodies that take back exactly what a did lists: its added labels come off, its removed
    labels go back, on the messages each concerned."""
    added, removed = _label_changes(did)
    order = list(dict.fromkeys(m for ids in (*added.values(), *removed.values()) for m in ids))
    if len(order) > MAX_MESSAGES:
        raise ValueError(f"Gmail changes at most {MAX_MESSAGES} messages at a time")
    return [
        body
        for body, _ in _group(
            {label: set(ids) for label, ids in removed.items()},
            {label: set(ids) for label, ids in added.items()},
            order,
        )
    ]


def undo_mail(act: OutgoingAct, service_id: str, context: ChannelContext) -> ChannelUndone | ChannelFailed:
    """Take a filing change or read mark back. With what the act did, exactly that is taken back and nothing else;
    an act from before that was recorded gets the reverse `batchModify` for the same messages."""

    def work(call: _Call) -> Answer:
        if act.kind != "mailbox":
            return ChannelFailed("refused", CANT_TAKE_BACK)
        if isinstance(act.did, dict) and isinstance(act.did.get("messages"), list):
            for body in _back_bodies(act.did):
                call.act("POST", f"{GMAIL}/messages/batchModify", body=body)
            return ChannelUndone()
        if len([a for a in act.about if a.service_id]) > MAX_MESSAGES:
            raise ValueError(f"Gmail changes at most {MAX_MESSAGES} messages at a time")
        labels = _label_ids(call) if act.action in ("move", "label") else {}
        _, undo = acting.mailbox_change(act, label_ids=labels)
        call.act("POST", f"{GMAIL}/messages/batchModify", body=undo)
        return ChannelUndone()

    return _run(context, MAIL_SCOPE, work, undoing=True)  # type: ignore[return-value]


def undo_calendar(act: OutgoingAct, service_id: str, context: ChannelContext) -> ChannelUndone | ChannelFailed:
    """Take a created event back (it is deleted and nobody is told, already gone counts as done), a move back (the
    earlier times return) or an answer back (the earlier answer returns). A cancel is never taken back."""

    def work(call: _Call) -> Answer:
        did = act.did if isinstance(act.did, dict) else {}
        event = _did_text(act, "event")
        if act.kind != "calendar":
            return ChannelFailed("refused", CANT_TAKE_BACK)
        if act.action == "create":
            method, path, params, body = acting.undo_create(event or service_id, act.calendar)
            call.act(method, CALENDAR + path, params, body, gone_ok=True)
            return ChannelUndone()
        if act.action == "move" and event and isinstance(did.get("start"), str) and isinstance(did.get("end"), str):
            method, path, params, body = acting.restore_times(act, event, did["start"], did["end"])
            call.act(method, CALENDAR + path, params, body)
            return ChannelUndone()
        if act.action == "answer" and event and isinstance(did.get("answer"), str):
            current = call.lookup(CALENDAR + acting._events(act, event))
            method, path, params, body = acting.restore_answer(act, event, did["answer"], attendees=_attendees(current))
            call.act(method, CALENDAR + path, params, body)
            return ChannelUndone()
        return ChannelFailed("refused", CANT_TAKE_BACK)

    return _run(context, CALENDAR_SCOPE, work, undoing=True)  # type: ignore[return-value]


# ---- status -----------------------------------------------------------------------------------------------------


def _found(context: ChannelContext, search: Callable[[_Call], Any], key: str) -> Answer:
    """Looks for what an attempt left behind. Found is `ChannelSent`; anything else, a failure included, is unknown:
    a search can lag behind a send, so "nothing found" never means "not sent"."""
    try:
        body = search(_Call(context, None))
    except (_Stop, ValueError):
        return ChannelUnknown()
    items = body.get(key) if isinstance(body, dict) else None
    first = items[0] if isinstance(items, list) and items else None
    found = first.get("id") if isinstance(first, dict) else None
    return ChannelSent(found) if isinstance(found, str) and found else ChannelUnknown()


def mail_status(attempt_key: str, context: ChannelContext) -> Answer:
    """What became of a send: the message with the Message-ID this attempt used, if Gmail has it."""

    def search(call: _Call) -> Any:
        wanted = acting.message_id(attempt_key, call.account).strip("<>")
        return call.lookup(
            f"{GMAIL}/messages", {"q": f"rfc822msgid:{wanted}", "includeSpamTrash": "true", "maxResults": "1"}
        )

    return _found(context, search, "messages")


def calendar_status(attempt_key: str, context: ChannelContext) -> Answer:
    """What became of a create: the event carrying this attempt's mark, on the main calendar."""

    def search(call: _Call) -> Any:
        return call.lookup(
            f"{CALENDAR}/calendars/primary/events",
            {
                "privateExtendedProperty": f"pmcAttempt={attempt_hash(attempt_key)}",
                "showDeleted": "true",
                "maxResults": "1",
            },
        )

    return _found(context, search, "items")


__all__ = [
    "ACTING_NOT_ALLOWED",
    "CALENDAR_CHANNEL",
    "MAIL_CHANNEL",
    "attempt_hash",
    "calendar_status",
    "folders",
    "mail_status",
    "send_calendar",
    "send_mail",
    "undo_calendar",
    "undo_mail",
]
